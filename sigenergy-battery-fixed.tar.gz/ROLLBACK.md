# Rollback handleiding — Sigenergy Battery app

Als een nieuwe release problemen veroorzaakt, kun je altijd terug naar een vorige versie.

---

## 1. Rollback via Git tag (lokale CLI)

1. Haal tags op:
   ```bash
   git fetch --tags
